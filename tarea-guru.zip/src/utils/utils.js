const quoteHomework = homework => {
    return { questions: 10, price: 20 }
}

module.exports = { quoteHomework }